//
//  PlayerModule.h
//  PlayerModule
//
//  Created by Muhammad Akram on 06/10/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for PlayerModule.
FOUNDATION_EXPORT double PlayerModuleVersionNumber;

//! Project version string for PlayerModule.
FOUNDATION_EXPORT const unsigned char PlayerModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PlayerModule/PublicHeader.h>


